//package com.ems.security;
//
//import com.ems.payloads.UserDto;
//
//public class JwtAuthResponse {
//    private  String token;
//
//    public String getToken() {
//        return token;
//    }
//
//    public void setToken(String token) {
//        this.token = token;
//    }
//
//    public void setUser(UserDto map) {
//        this.map=map
//    }
//    public void getUser(UserDto map) {
//    }
//}
