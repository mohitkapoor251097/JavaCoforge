package com.ems.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ems.entities.Employee;
import com.ems.payloads.ApiResponse;
import com.ems.payloads.EmployeeDto;
import com.ems.services.EmployeeService;
import com.ems.services.FileService;

@RestController
@RequestMapping("/api/")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private FileService fileService;
	
	@Value("${project.image}")
	private String path;
	//creat
	//@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/user/{userId}/employee")
	public ResponseEntity<EmployeeDto> createEmployee(@RequestBody EmployeeDto employeeDto,@PathVariable("userId") int userId)
	{
		System.out.print(userId);
		EmployeeDto createEmployee= this.employeeService.createEmployee(employeeDto, userId);
	return new ResponseEntity<EmployeeDto>(createEmployee,HttpStatus.CREATED);
	}
	
	
	

	
	
	//getAllEmployees
	@GetMapping("/employees")
	public ResponseEntity<List<EmployeeDto>> getAllEmployee1()
	{
		List<EmployeeDto> allEmployee=this.employeeService.getAllEmployee();
	return new ResponseEntity<List<EmployeeDto>>(allEmployee,HttpStatus.OK);
	}
	
	
//	//getAllEmployees
//	@GetMapping("/employees")
//	public ResponseEntity<List<EmployeeDto>> getAllEmployee1(@RequestParam(value="pageNumber",defaultValue="1",required=false ) Integer pageNumber,
//			@RequestParam(value="pageSize" ,defaultValue="3",required=false) Integer pageSize)
//	{
//		List<EmployeeDto> allEmployee=this.employeeService.getAllEmployee(pageNumber,pageSize);
//	return new ResponseEntity<List<EmployeeDto>>(allEmployee,HttpStatus.OK);
//	}
	
//	//single emp
//	@GetMapping("/user/{uid}/employees/{employeeId}")
//	public ResponseEntity<EmployeeDto> getAllEmployee(@PathVariable Integer employeeId,@PathVariable Integer uid)
//	{
//		EmployeeDto employeeDto=this.employeeService.getEmployeeById(employeeId,uid);
//		return new ResponseEntity<EmployeeDto>(employeeDto,HttpStatus.OK);
//	}
	
	//single emp
		@GetMapping("/employees/{employeeId}")
		public ResponseEntity<EmployeeDto> getAllEmployee(@PathVariable Integer employeeId)
		{
			EmployeeDto employeeDto=this.employeeService.getEmployeeById(employeeId);
			return new ResponseEntity<EmployeeDto>(employeeDto,HttpStatus.OK);
		}
		
		
		
		
	
		//delete
		@DeleteMapping("/employees/{empId}")
		public ApiResponse deleteEmployee(@PathVariable Integer empId)
		{
             this.employeeService.deleteEmployee(empId);
             return new ApiResponse("Employees is deleted...",true);
		}
//		
//		
//		//update
				@PutMapping("/employees/{empId}")
				public ResponseEntity<EmployeeDto> updateEmployee(@RequestBody EmployeeDto employeeDto, @PathVariable Integer empId)
				{
		           EmployeeDto updateEmploye= this.employeeService.updateEmployee(employeeDto, empId);
		           return new ResponseEntity<EmployeeDto>(updateEmploye,HttpStatus.OK);
				}
//		
	
				
				
				
				
				
				
				
				//post img
			
				
				@PostMapping("/employess/image/upload/{empId}")
				public ResponseEntity<EmployeeDto> uploadImage(@RequestParam("image") MultipartFile image,@PathVariable Integer empId) throws IOException
				{
			   EmployeeDto employeeDto=this.employeeService.getEmployeeById(empId);
				String fileName=this.fileService.uploadImage(path, image);
					
				employeeDto.setImageName(fileName);
				EmployeeDto updateEmploee=this.employeeService.updateEmployee(employeeDto, empId);
					return new ResponseEntity<EmployeeDto>(updateEmploee,HttpStatus.OK);
				}
				
				
				
				//serve img
				
				@GetMapping(value="/post/image/{imageName}",produces=MediaType.IMAGE_JPEG_VALUE)
				public void downloadImage(
				@PathVariable("imageName") String imageName,
				HttpServletResponse response) throws IOException
				{
					
				InputStream resource=this.fileService.getSource(path, imageName);
				response.setContentType(MediaType.IMAGE_JPEG_VALUE);
				StreamUtils.copy(resource,response.getOutputStream());
				}
				
				
}
