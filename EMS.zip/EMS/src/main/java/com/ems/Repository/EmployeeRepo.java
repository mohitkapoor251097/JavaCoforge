package com.ems.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ems.entities.Employee;
import com.ems.entities.User;

public interface EmployeeRepo extends JpaRepository<Employee,Integer> {
	
	List<Employee> findByUser(User user);
	
	@Query("select u from Employee u where u.empId=:empId and u.id=:id")
	public Employee findByUserIdAndEmployeeId(@Param("empId") int empId,@Param("id") int id);

}
