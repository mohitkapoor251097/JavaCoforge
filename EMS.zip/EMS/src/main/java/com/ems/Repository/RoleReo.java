package com.ems.Repository;

import com.ems.entities.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleReo extends JpaRepository<Role,Integer> {
}
