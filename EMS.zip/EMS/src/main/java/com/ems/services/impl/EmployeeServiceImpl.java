package com.ems.services.impl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ems.Repository.EmployeeRepo;
import com.ems.Repository.UserRepo;
import com.ems.entities.Employee;
import com.ems.entities.User;
import com.ems.exception.ResourceNotFoundException;
import com.ems.payloads.EmployeeDto;
import com.ems.services.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

@Autowired
private EmployeeRepo employeeRepo;

@Autowired
private ModelMapper modelMapper;

@Autowired
private UserRepo userRepo;
	@Override
	public EmployeeDto createEmployee(EmployeeDto employeeDto,Integer userId) {
	
		User user=this.userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User","user Id",userId));
		
		
		Employee employee=this.modelMapper.map(employeeDto, Employee.class);
		employee.setImageName("default.png");
		employee.setAddedDate(new Date());
		employee.setUser(user);
		Employee newemp=this.employeeRepo.save(employee);
		return this.modelMapper.map(newemp, EmployeeDto.class);
	}

	@Override
	public EmployeeDto updateEmployee(EmployeeDto employeeDto, Integer employeeId) {
		Employee employee=	this.employeeRepo.findById(employeeId).orElseThrow(()-> new ResourceNotFoundException("Employee","employee Id",employeeId));
		employee.setCode(employeeDto.getCode());
		employee.setEmail(employeeDto.getEmail());
		employee.setAbout(employeeDto.getAbout());
		employee.setImageName(employeeDto.getImageName());
		
	Employee updateEmployee=this.employeeRepo.save(employee);
	return this.modelMapper.map(updateEmployee, EmployeeDto.class);
	}

	@Override
	public void deleteEmployee(Integer employeeId) {
	Employee employee=	this.employeeRepo.findById(employeeId).orElseThrow(()-> new ResourceNotFoundException("Employee","employee Id",employeeId));
		this.employeeRepo.delete(employee);
	
	}
//
@Override
	public List<EmployeeDto> getAllEmployee() {
		List<Employee> allEmployees=this.employeeRepo.findAll();
		List<EmployeeDto> employeeDtos=allEmployees.stream().map((employee)->this.modelMapper.map(employee,EmployeeDto.class)).collect(Collectors.toList());
		return employeeDtos;
	}
	
	

//	@Override
//	public List<EmployeeDto> getAllEmployee(Integer pageNumber,Integer pageSize) {
//		
//	//	int pageSize=5;
//		//int pageNumber=1;
//		
//		Pageable p=PageRequest.of(pageNumber, pageSize);
//		Page<Employee> pageEmployees=this.employeeRepo.findAll(p);
//		List<Employee> allEmployees=pageEmployees.getContent();
//		List<EmployeeDto> employeeDtos=allEmployees.stream().map((employee)->this.modelMapper.map(employee,EmployeeDto.class)).collect(Collectors.toList());
//		return employeeDtos;
//	}

	@Override
	public EmployeeDto getEmployeeById(Integer employeeId) {
		Employee employee=this.employeeRepo.findById(employeeId).orElseThrow(()-> new ResourceNotFoundException("Employee","employee Id",employeeId));
		
		return this.modelMapper.map(employee, EmployeeDto.class);
	}

	@Override
	public List<Employee> searchEmployee(String keyword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeeDto> getEmployeeByUser(Integer userId) {

		User user=this.userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User","user Id",userId));
	List<Employee> employees=	this.employeeRepo.findByUser(user);
	List<EmployeeDto> employeesDtos=employees.stream().map((employee)->this.modelMapper.map(employee, EmployeeDto.class)).collect(Collectors.toList());
		return employeesDtos;
	}

}
