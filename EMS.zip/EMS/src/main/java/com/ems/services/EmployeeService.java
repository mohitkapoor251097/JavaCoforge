package com.ems.services;

import java.util.List;

import com.ems.entities.Employee;
import com.ems.payloads.EmployeeDto;

public interface EmployeeService {
	
	
	//create
	
	EmployeeDto createEmployee(EmployeeDto employeeDto,Integer userId);
	
	//update
	EmployeeDto updateEmployee(EmployeeDto employeeDto,Integer employeeId);
	
	//delete
	
	void deleteEmployee(Integer employeeId);
	
	//get all emp
	
	List<EmployeeDto> getAllEmployee();
	
//	List<EmployeeDto> getAllEmployee(Integer pageNumber,Integer pageSize);
	
	//single
	
	EmployeeDto getEmployeeById(Integer employeeId);
	
	
	//search emp
	List<Employee> searchEmployee(String keyword);
	
	List<EmployeeDto> getEmployeeByUser(Integer userId);
}
