package com.ems.services;

import java.util.List;
import java.util.Optional;

import com.ems.entities.User;
import com.ems.payloads.UserDto;

public interface UserService {
	
	UserDto registerNewUser(UserDto userDto);
	UserDto createUser(UserDto user);
	
	UserDto updateUser(UserDto user,Integer userId);
	
	UserDto getUserById(Integer userId);
	Optional<User> getUserId(Integer userId);
	List<UserDto> getAllUsers();
	
	void deleteUser(Integer userId);

}
