package com.ems.config;

public class AppConstants {
    public static  final Integer NORMAL_USER=502;
    public static  final Integer ADMIN_USER=501;
}
